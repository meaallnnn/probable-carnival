from .utubebot import UtubeBot


if __name__ == '__main__':
    UtubeBot().run()
